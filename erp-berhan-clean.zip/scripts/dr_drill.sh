#!/usr/bin/env bash
set -euo pipefail
python scripts/dr_drill.py
