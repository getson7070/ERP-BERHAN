"""Collection of core application blueprints."""
