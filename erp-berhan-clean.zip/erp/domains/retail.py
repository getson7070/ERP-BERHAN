SCHEMA = {"stores": ["id SERIAL PRIMARY KEY", "org_id INT", "location TEXT"]}
WORKFLOWS = {"stock_replenishment": ["request", "approve", "restock"]}
