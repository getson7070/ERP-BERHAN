"""First-party integration API blueprints."""
