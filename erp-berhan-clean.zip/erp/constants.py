# erp/constants.py
# Keep audit constants here to avoid circular imports.
AUDIT_CHAIN_BROKEN = "AUDIT_CHAIN_BROKEN"

# (Optional – add more here as your codebase uses them)
# AUDIT_LOGIN_SUCCESS = "AUDIT_LOGIN_SUCCESS"
# AUDIT_LOGIN_FAILURE = "AUDIT_LOGIN_FAILURE"
# AUDIT_SECURITY_EVENT = "AUDIT_SECURITY_EVENT"
