# erp/observability.py
"""Simple observability placeholders. Extend with real metrics/exporters when ready."""
KPI_SALES_MV_AGE = "kpi:sales:mv_age"
