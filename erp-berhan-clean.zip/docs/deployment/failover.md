# Failover Procedures

1. Promote standby database.
2. Redeploy application pods pointing to new primary.
3. Verify service health checks.
