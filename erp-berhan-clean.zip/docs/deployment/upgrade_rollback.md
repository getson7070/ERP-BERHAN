# Upgrade & Rollback

Use rolling updates with zero-downtime strategy.
For rollback, redeploy previous container image and restore database snapshot.
