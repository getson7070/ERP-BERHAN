# UX Guidelines

This project follows industry-standard UX and accessibility practices and adheres to the BERHAN Pharma SOP and corporate policy (see docs/BERHAN_SOP_PACK.md):

- **Responsive design:** verify layouts across mobile (375px), tablet (768px), and desktop (1280px) viewports. Reference snapshots live in [`docs/ux/snapshots`](./ux/snapshots).
- **Accessible markup:** templates follow WCAG 2.1 AA with semantic headings, ARIA landmarks, and labels. Automated checks run via `pa11y-ci` (best effort) and `axe`.
- **Internationalization:** translation catalogs live under `translations/`, and a locale switcher in the navbar lets users toggle supported languages including English, Amharic, and Farsi.
- **Dark mode:** toggle provided with persistent preference stored in `localStorage`.
- **Form validation:** Bootstrap validation styles used with `needs-validation` class and custom scripts to ensure keyboard and screen reader support.
- **CSP nonces:** all inline scripts/styles use `csp_nonce()` to align with our Content Security Policy.
- **PWA support:** service worker and web app manifest enable offline access and installable experience on mobile.
- **Guided tour:** first-time users see a popover tour that highlights navigation and the theme toggle.
- **Graceful placeholders:** unfinished pages should display clear "under development" notices and navigation back to the dashboard to avoid dead ends.

Developers should run:

```bash
npx pa11y-ci templates/base.html || true  # requires Chromium dependencies
pytest tests/test_template_accessibility.py::test_base_template_axe
```

before committing frontend changes to catch regressions.

See [Cross-Browser and Accessibility Audit](./browser_accessibility_review.md) for a full checklist covering browser compatibility, manual accessibility review, service worker and CSP verification, database integrity, and ongoing maintenance.

Supported browser versions are tracked in [browser_matrix.md](./browser_matrix.md), and outcomes of manual accessibility reviews belong in [accessibility_audit_log.md](./accessibility_audit_log.md).
