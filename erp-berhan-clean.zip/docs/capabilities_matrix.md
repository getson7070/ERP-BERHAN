# Capabilities Matrix

| Module | Key Features |
|--------|--------------|
| CRM | Customer management, contacts, deals |
| HR | Employee records, onboarding, payroll |
| Finance | Transactions, compliance reports |
| Procurement | Purchase orders, supplier management |
| Manufacturing | Production planning, inventory control |
| Projects | Task tracking, timelines |
