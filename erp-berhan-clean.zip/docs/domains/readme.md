# Domain Configurations

Healthcare and retail examples demonstrate tailored schemas and workflows.
