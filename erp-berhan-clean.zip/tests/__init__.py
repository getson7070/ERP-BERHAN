"""Test suite package for type checking.

This empty file ensures the ``tests`` directory is treated as a package so
 tools like ``mypy`` resolve modules consistently and pytest can import shared
 helpers.
"""
